import SwiftUI
import PlaygroundSupport



struct ContentView:View {
    @State var selectedItem:Int = -1
    var body: some View{
        VStack{
            RowView(item:selectedItem)
                .font(.largeTitle)
            ListView(selectedItem: $selectedItem)
        }
    }
}

let view = ContentView()
let vc = UIHostingController(rootView: view)
PlaygroundPage.current.liveView = vc

