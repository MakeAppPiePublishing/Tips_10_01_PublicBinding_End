import SwiftUI
public struct RowView:View {
    var item:Int
    public init(item:Int){self.item = item}
    public var body: some View{
        HStack{
            Image(systemName: "\(item).circle.fill")
                .padding(.trailing)
            Text(NumberFormatter.localizedString(from: NSNumber(value: item), number: .spellOut))
        }
    }
}

