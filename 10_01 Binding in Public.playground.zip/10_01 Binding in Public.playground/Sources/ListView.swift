import SwiftUI

public struct ListView:View {
    @Binding var selectedItem:Int
    public init(selectedItem:Binding<Int>){
        self._selectedItem = selectedItem
    }
    public var body: some View {
        List{
            ForEach(1...10,id: \.self){ item in
                RowView(item: item)
                    .onTapGesture{
                        self.selectedItem = item
                }//TapGesture
            }
        }
    }
}

